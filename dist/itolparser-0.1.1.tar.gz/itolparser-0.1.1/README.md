# itolparser
Small script to produce iTOL colorstrip metadata files from a table
